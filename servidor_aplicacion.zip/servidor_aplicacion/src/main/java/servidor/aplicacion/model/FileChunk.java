package servidor.aplicacion.model;

import java.sql.Timestamp;

public class FileChunk {
    private Integer id;
    private Long fileId;
    private Long nodeId;
    private Integer chunkIndex;
    private String checksum;
    private Boolean replicated;
    private Timestamp createdAt;

    public FileChunk() {
        this.replicated = false;
    }

    public FileChunk(Long fileId, Long nodeId, Integer chunkIndex) {
        this();
        this.fileId = fileId;
        this.nodeId = nodeId;
        this.chunkIndex = chunkIndex;
    }

    public FileChunk(Long fileId, Long nodeId, Integer chunkIndex, String checksum) {
        this(fileId, nodeId, chunkIndex);
        this.checksum = checksum;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public Long getNodeId() {
        return nodeId;
    }

    public void setNodeId(Long nodeId) {
        this.nodeId = nodeId;
    }

    public Integer getChunkIndex() {
        return chunkIndex;
    }

    public void setChunkIndex(Integer chunkIndex) {
        this.chunkIndex = chunkIndex;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }

    public Boolean getReplicated() {
        return replicated;
    }

    public void setReplicated(Boolean replicated) {
        this.replicated = replicated;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isReplicated() {
        return replicated != null && replicated;
    }

    public void markAsReplicated() {
        this.replicated = true;
    }

    public void markAsNotReplicated() {
        this.replicated = false;
    }

    public String getUniqueKey() {
        return fileId + "_" + nodeId + "_" + chunkIndex;
    }

    @Override
    public String toString() {
        return "FileChunk{" +
                "id=" + id +
                ", fileId=" + fileId +
                ", nodeId=" + nodeId +
                ", chunkIndex=" + chunkIndex +
                ", checksum='" + checksum + '\'' +
                ", replicated=" + replicated +
                ", createdAt=" + createdAt +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        FileChunk fileChunk = (FileChunk) o;

        if (!fileId.equals(fileChunk.fileId))
            return false;
        if (!nodeId.equals(fileChunk.nodeId))
            return false;
        return chunkIndex.equals(fileChunk.chunkIndex);
    }

    @Override
    public int hashCode() {
        int result = fileId.hashCode();
        result = 31 * result + nodeId.hashCode();
        result = 31 * result + chunkIndex.hashCode();
        return result;
    }
    
    public int getChunkNumber() {
        return chunkIndex != null ? chunkIndex : 0;
    }
    
    public void setChunkNumber(int chunkNumber) {
        this.chunkIndex = chunkNumber;
    }
    
    public String getChunkHash() {
        return checksum;
    }
    
    public void setChunkHash(String chunkHash) {
        this.checksum = chunkHash;
    }
    
    public int getSize() {
        return 1024 * 1024; // 1MB
    }
    
    public void setSize(int size) {
    }
    
    public void setCreatedAt(java.time.LocalDateTime createdAt) {
        this.createdAt = java.sql.Timestamp.valueOf(createdAt);
    }
}
