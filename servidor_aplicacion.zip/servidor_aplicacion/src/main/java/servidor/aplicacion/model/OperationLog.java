package servidor.aplicacion.model;

public class OperationLog {
    
}
