package servidor.aplicacion.model;

public class Session {
    
}
