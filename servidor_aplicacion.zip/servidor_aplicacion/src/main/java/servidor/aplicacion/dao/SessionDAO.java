package servidor.aplicacion.dao;

public class SessionDAO {
    
}
