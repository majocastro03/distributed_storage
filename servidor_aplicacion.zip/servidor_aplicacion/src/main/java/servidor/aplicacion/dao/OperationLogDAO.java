package servidor.aplicacion.dao;

public class OperationLogDAO {
    
}
